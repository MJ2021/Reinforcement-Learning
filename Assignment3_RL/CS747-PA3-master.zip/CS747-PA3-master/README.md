# Programming Assignment 3
(TA : Harsh Shah and Shrey Modi)  
This repository contains code for PA3 of CS747 - Foundations of Learning Agents (Autumn 2023). Clone/download this repository and read instructions over [here](https://www.cse.iitb.ac.in/~shivaram/teaching/cs747-a2023/index.html).

(simulator taken from [here](https://github.com/max-kov/pool))  